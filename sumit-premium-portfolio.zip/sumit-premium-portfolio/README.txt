SUMIT BABU — PREMIUM DEVELOPER PORTFOLIO
========================================

FILES
- index.html       Main portfolio page
- style.css        Main portfolio styling
- script.js        Main page menu and icon setup
- visit.html       Separate Visit / Demo Gallery page
- visit.css        Demo gallery styling
- demos/launchpad.html  SaaS landing page demo
- demos/storefront.html Product page demo
- demos/dashboard.html  Analytics dashboard demo
- demos/demo.css       Styles for the independent demos
- demos/demo.js        Demo interactions

HOW TO USE ON GITHUB (PHONE OR COMPUTER)
1. Download and extract this ZIP.
2. Open your existing GitHub repository: deepsanatani38-ux/ny-web-
3. Upload the files and the complete "demos" folder into the repository root.
4. If GitHub asks whether to replace index.html/style.css/script.js, choose replace.
5. Keep folder names and file names exactly the same (case-sensitive).
6. Open repository Settings > Pages and make sure deployment is enabled from your main branch / root.
7. Wait for deployment, then open your GitHub Pages URL.

IMPORTANT
- The "Visit live demos" button opens visit.html.
- Each demo has its own separate HTML file and shared demo.css/demo.js.
- The dashboard numbers are fictional sample data.
- The product page bag and landing page form are demo-only. They do not take real orders or payments.
- Replace social links, email, education dates or text if any detail changes.
- This project uses Google Fonts and Lucide icons from CDNs; an internet connection is needed for those assets.
- GitHub Pages is suitable for a portfolio/demo showcase. Use appropriate commercial hosting and payment services if you later launch a paid client or e-commerce site.
