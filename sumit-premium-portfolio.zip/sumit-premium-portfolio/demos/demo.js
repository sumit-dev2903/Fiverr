// Small interactions for the independent demo pages.
const form=document.getElementById('demoForm');
if(form){form.addEventListener('submit',e=>{e.preventDefault();document.getElementById('result').textContent='Thanks! This demo form is front-end only; no data was sent.';form.reset()})}
let qty=1;const qtyEl=document.getElementById('qty');const countEl=document.getElementById('count');let bag=0;
const minus=document.getElementById('minus'),plus=document.getElementById('plus'),add=document.getElementById('add');
if(minus&&plus&&qtyEl){minus.addEventListener('click',()=>{qty=Math.max(1,qty-1);qtyEl.textContent=qty;updateAdd()});plus.addEventListener('click',()=>{qty=Math.min(9,qty+1);qtyEl.textContent=qty;updateAdd()});}
function updateAdd(){if(add)add.textContent=`ADD TO BAG — ₹${(1499*qty).toLocaleString('en-IN')}`}
if(add){add.addEventListener('click',()=>{bag+=qty;countEl.textContent=bag;document.getElementById('message').textContent=`Added ${qty} item(s) to demo bag. No real checkout or payment is connected.`})}
const period=document.getElementById('period');
if(period){period.addEventListener('change',()=>{const data={'This month':['₹48,290','8,420'],'Last month':['₹42,710','7,780'],'This week':['₹12,480','2,140']};document.getElementById('revenue').textContent=data[period.value][0];document.getElementById('visitors').textContent=data[period.value][1]})}
